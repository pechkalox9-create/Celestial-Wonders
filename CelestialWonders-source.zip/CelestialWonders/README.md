# Celestial Wonders

An original Fabric mod for Minecraft Java 1.21.11. During clear nights, players may see rare animated shooting stars. Each meteor gets a randomized direction, speed, lifetime, and particle palette. The head moves each server tick while layered particles create a tapered sparkling tail.

## Requirements
- Minecraft Java 1.21.11
- Fabric Loader 0.18.0 or newer
- Fabric API 0.141.1+1.21.11
- Java 21

## Build
Install Gradle 8.14+ (or open this folder in IntelliJ IDEA with the Minecraft Development plugin), then run:

```bash
gradle build
```

The remapped mod jar will be created in `build/libs/`.

## Install
Copy `celestial-wonders-1.0.0.jar` from `build/libs/` into your Minecraft `mods` folder alongside Fabric API.

## Notes
This is an original implementation and does not include code, assets, or animations copied from another mod. Meteor particles are emitted by the server so players in multiplayer can see the same event.
