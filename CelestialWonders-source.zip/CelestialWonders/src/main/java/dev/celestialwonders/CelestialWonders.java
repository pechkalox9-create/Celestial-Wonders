package dev.celestialwonders;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class CelestialWonders implements ModInitializer {
    private static final Map<UUID, Meteor> ACTIVE_METEORS = new HashMap<>();

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(CelestialWonders::tick);
    }

    private static void tick(MinecraftServer server) {
        for (ServerLevel level : server.getAllLevels()) {
            if (!level.isNight() || level.isRaining()) continue;
            for (ServerPlayer player : level.players()) {
                UUID id = player.getUUID();
                Meteor meteor = ACTIVE_METEORS.get(id);
                if (meteor == null) {
                    RandomSource random = level.getRandom();
                    // A gentle, uncommon chance per player per second while it is night.
                    if (random.nextInt(1200) == 0) {
                        ACTIVE_METEORS.put(id, Meteor.create(player, random));
                    }
                } else if (meteor.levelKey.equals(level.dimension().location().toString())) {
                    meteor.tick(level);
                    if (meteor.age >= meteor.lifetime) ACTIVE_METEORS.remove(id);
                } else {
                    ACTIVE_METEORS.remove(id);
                }
            }
        }
    }

    private static final class Meteor {
        private final String levelKey;
        private Vec3 position;
        private final Vec3 velocity;
        private final ParticleOptions core;
        private final ParticleOptions glimmer;
        private final int lifetime;
        private int age;

        private Meteor(String levelKey, Vec3 position, Vec3 velocity,
                       ParticleOptions core, ParticleOptions glimmer, int lifetime) {
            this.levelKey = levelKey;
            this.position = position;
            this.velocity = velocity;
            this.core = core;
            this.glimmer = glimmer;
            this.lifetime = lifetime;
        }

        static Meteor create(ServerPlayer player, RandomSource random) {
            double side = random.nextBoolean() ? 1.0 : -1.0;
            double startX = player.getX() + (random.nextDouble() * 44.0 - 22.0);
            double startZ = player.getZ() + (random.nextDouble() * 44.0 - 22.0);
            double startY = Math.min(player.getY() + 42.0, player.serverLevel().getMaxY() - 4.0);
            int palette = random.nextInt(4);
            ParticleOptions core = switch (palette) {
                case 0 -> ParticleTypes.END_ROD;
                case 1 -> ParticleTypes.SOUL_FIRE_FLAME;
                case 2 -> ParticleTypes.FLAME;
                default -> ParticleTypes.WAX_ON;
            };
            ParticleOptions glimmer = palette == 1 ? ParticleTypes.SOUL : ParticleTypes.FIREWORK;
            Vec3 velocity = new Vec3(-side * (0.48 + random.nextDouble() * 0.35),
                    -0.42 - random.nextDouble() * 0.20,
                    side * (0.12 + random.nextDouble() * 0.18));
            return new Meteor(player.serverLevel().dimension().location().toString(),
                    new Vec3(startX, startY, startZ), velocity, core, glimmer, 34 + random.nextInt(18));
        }

        void tick(ServerLevel level) {
            position = position.add(velocity);
            age++;
            double spread = 0.035 + (age % 3) * 0.012;
            // The moving head and layered tail create a tapered, shimmering streak.
            level.sendParticles(core, position.x, position.y, position.z, 2,
                    spread, spread, spread, 0.005);
            Vec3 tail = position.subtract(velocity.scale(1.8));
            level.sendParticles(glimmer, tail.x, tail.y, tail.z, 2,
                    0.10, 0.08, 0.10, 0.012);
            if (age % 3 == 0) {
                Vec3 farTail = position.subtract(velocity.scale(3.8));
                level.sendParticles(ParticleTypes.END_ROD, farTail.x, farTail.y, farTail.z,
                        1, 0.04, 0.04, 0.04, 0.002);
            }
        }
    }
}
